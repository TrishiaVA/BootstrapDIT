/*---Main Menu Selector---*/
function openMenu(pageName,element,color){
    var i, menucontent, menulink;
    menucontent = document.getElementsByClassName("menucontent");
    for (i = 0; i < menucontent.length; i++) {
      menucontent[i].style.display = "none";
    }
    menulink = document.getElementsByClassName("menulink");
    for (i = 0; i < menulink.length; i++) {
      menulink[i].style.backgroundColor = "";
    }
    document.getElementById(pageName).style.display = "block";
    elmnt.style.backgroundColor = color;
  }
  document.getElementById("defaultOpen1").click();

/*---Sign Up Window---*/
function SignUpWindow(){
    var answer = window.confirm("This link will open a new tab which will process your sign-up information, proceed?");
    if (answer) {
    window.open("signup.html");
    }
    else {
   return;
    }
  }